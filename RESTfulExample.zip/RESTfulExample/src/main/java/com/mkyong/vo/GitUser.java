package com.mkyong.vo;

import org.apache.commons.lang.builder.ToStringBuilder;

public class GitUser {

	String login;
	long id;
	String avatar_url;
	String url;
	String followers_url;
	String following_url;
	String type;
	boolean site_admin;
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAvatar_url() {
		return avatar_url;
	}
	public void setAvatar_url(String avatar_url) {
		this.avatar_url = avatar_url;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getFollowers_url() {
		return followers_url;
	}
	public void setFollowers_url(String followers_url) {
		this.followers_url = followers_url;
	}
	public String getFollowing_url() {
		return following_url;
	}
	public void setFollowing_url(String following_url) {
		this.following_url = following_url;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean isSite_admin() {
		return site_admin;
	}
	public void setSite_admin(boolean site_admin) {
		this.site_admin = site_admin;
	}
	
	public String toString() {
		   return ToStringBuilder.reflectionToString(this);
	}
	
//	private static final ObjectMapper OBJECT_MAPPER_SINGLETON = new ObjectMapper();
//	public static String toStringUsingJackson(final Object object) {
//	    try {
//	        return OBJECT_MAPPER_SINGLETON.writeValueAsString(object);
//	    } catch (final JsonProcessingException e) {
//	        return String.valueOf(object);
//	    }
//	}
	
	/*
	{
		"login":"yuanchuan"
		,"id":250426
		,"avatar_url":"https://avatars1.githubusercontent.com/u/250426?v=4"
		,"gravatar_id":""
		,"url":"https://api.github.com/users/yuanchuan"
		,"html_url":"https://github.com/yuanchuan"
		,"followers_url":"https://api.github.com/users/yuanchuan/followers"
		,"following_url":"https://api.github.com/users/yuanchuan/following{/other_user}"
		,"gists_url":"https://api.github.com/users/yuanchuan/gists{/gist_id}"
		,"starred_url":"https://api.github.com/users/yuanchuan/starred{/owner}{/repo}"
		,"subscriptions_url":"https://api.github.com/users/yuanchuan/subscriptions"
		,"organizations_url":"https://api.github.com/users/yuanchuan/orgs"
		,"repos_url":"https://api.github.com/users/yuanchuan/repos"
		,"events_url":"https://api.github.com/users/yuanchuan/events{/privacy}"
		,"received_events_url":"https://api.github.com/users/yuanchuan/received_events"
		,"type":"User","site_admin":false
	}*/
}
