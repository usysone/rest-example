package com.mycode.client;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import java.util.List;

//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
//import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.mycode.vo.GitUser;

public class JerseyClientGet {
	
	
	//https://api.github.com/users/2/followers
	public String getUsersFollowers(String user) {
		String str = "n/a";
		
		try {

			Client client = Client.create();

			System.out.println("user = "+ user);
			
			WebResource webResource = client
			   .resource("https://api.github.com/users/" + user + "/followers");

			ClientResponse response = webResource.accept("application/json")
	                   .get(ClientResponse.class);

			if (response.getStatus() != 200) {
			   throw new RuntimeException("Failed : HTTP error code : "
				+ response.getStatus());
			}

			str = response.getEntity(String.class);

			System.out.println("Output from Server .... \n");
			System.out.println(str);

		  } catch (Exception e) {

			e.printStackTrace();

		  }
		
		//JSONObject jsonObj = new JSONObject("{\"phonetype\":\"N95\",\"cat\":\"WP\"}");
		//Gson gson = new GsonBuilder().create();
		//gson.toJson(str);
		//System.out.println("::"+ gson + "::");
		
		Gson gson = new Gson();
		GitUser[] followers;
		//followers = gson.fromJson(str, followers.class);
		List<GitUser> list = gson.fromJson(str, new TypeToken<List<GitUser>>(){}.getType());
		
		for(GitUser u : list) {
			System.out.println(u.getLogin() + ", " + u.getId());
			System.out.println(u);
		}
		
		return str;
	}
	
	//https://api.github.com/users/1
	public String getGitUserDetails(String user) {
		String str = "n/a";
		
		try {

			Client client = Client.create();

			WebResource webResource = client
			   .resource("https://api.github.com/users/" + user);

			ClientResponse response = webResource.accept("application/json")
	                   .get(ClientResponse.class);

			if (response.getStatus() != 200) {
			   throw new RuntimeException("Failed : HTTP error code : "
				+ response.getStatus());
			}

			str = response.getEntity(String.class);

			System.out.println("Output from Server .... \n");
			System.out.println(str);

		  } catch (Exception e) {

			e.printStackTrace();

		  }
		
		
		
		return str;
	}
	
	

  public static void main(String[] args) {
	
	  /*
	  try {

		Client client = Client.create();

		WebResource webResource = client
		   .resource("http://localhost:8080/RESTfulExample/rest/hello/madhu");

		ClientResponse response = webResource.accept("application/json")
                   .get(ClientResponse.class);

		if (response.getStatus() != 200) {
		   throw new RuntimeException("Failed : HTTP error code : "
			+ response.getStatus());
		}

		String output = response.getEntity(String.class);

		System.out.println("Output from Server .... \n");
		System.out.println(output);

	  } catch (Exception e) {

		e.printStackTrace();

	  }*/
	  
	  JerseyClientGet client = new JerseyClientGet();
	  String resp = client.getGitUserDetails("2");
	  String resp2 = client.getUsersFollowers("2");

	}
}
