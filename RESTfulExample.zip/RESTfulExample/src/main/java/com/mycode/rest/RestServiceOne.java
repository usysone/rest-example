package com.mycode.rest;
 
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import com.mycode.client.JerseyClientGet;
 
@Path("/gitfollwers")
public class RestServiceOne {
 
	@GET
	@Path("/{param}")
	public Response getGitFollowers(@PathParam("param") String username) {
 
		System.out.println("username = "+ username);
		
		//String output = "Jersey say : " + msg;
		JerseyClientGet client = new JerseyClientGet();
 
		String responseFromGit = client.getUsersFollowers(username);
		
		return Response.status(200).entity(responseFromGit).build();
 
	}
 
}